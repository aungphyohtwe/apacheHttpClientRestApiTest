package json.test.client;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;

public class JsonConnectHelper {
	
	protected HttpResponse httpResponse(HttpClient client, String httpMethod, String uri, StringEntity jsonEntity) {
	
	  HttpResponse response = null;
	  switch (httpMethod) {
	    case "GET":
			HttpGet getRequest = new HttpGet(uri);
			getRequest.addHeader("Authorization", "Bearer tjzkJhm7vexALDqZZeqVAjPyGDsE6iQx4JQM");
			getRequest.addHeader("Content-Type", "application/json");
			try {
				response = client.execute(getRequest);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return response;
		case "POST":
			HttpPost postRequest = new HttpPost(uri);
			postRequest.addHeader("Authorization", "Bearer tjzkJhm7vexALDqZZeqVAjPyGDsE6iQx4JQM");
			postRequest.addHeader("Content-Type", "application/json");
			postRequest.setEntity(jsonEntity);
			try {
				response = client.execute(postRequest);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return response;
		case "PUT":
			HttpPut putRequest = new HttpPut(uri);
			putRequest.addHeader("Authorization", "Bearer tjzkJhm7vexALDqZZeqVAjPyGDsE6iQx4JQM");
			putRequest.addHeader("Content-Type", "application/json");
			putRequest.setEntity(jsonEntity);
			try {
				response = client.execute(putRequest);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return response;
		case "PATCH":
			HttpPatch patchRequest = new HttpPatch(uri);
			patchRequest.addHeader("Authorization", "Bearer tjzkJhm7vexALDqZZeqVAjPyGDsE6iQx4JQM");
			patchRequest.addHeader("Content-Type", "application/json");
			patchRequest.setEntity(jsonEntity);
			try {
				response = client.execute(patchRequest);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return response;
		default:
		  throw new IllegalArgumentException("Invalid HTTP method: " + httpMethod);
	  }
	}
}
