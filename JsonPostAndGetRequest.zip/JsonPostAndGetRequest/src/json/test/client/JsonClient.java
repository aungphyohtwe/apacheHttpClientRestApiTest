package json.test.client;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import json.test.bean.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import json.test.bean.Posts;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class JsonClient {

	public static void main(String[] args) {
		String jsonFilePath = args[0];
		String method = args[1];
		String urlSegement = args[2];
		String jsonOutput = args[3];
		if(!args[0].isEmpty()) {
			System.out.println(args[0]);
		}
		
		if(!args[1].isEmpty()) {
			System.out.println(args[1]);
		}
		
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(jsonFilePath));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 Posts posts = new Gson().fromJson(br, Posts.class);
		 
		 List<Data> postsList = posts.getData();
		 String mainUrl = "https://gorest.co.in";
		 String url = mainUrl + "/" + urlSegement;
		 
		 if (!method.equals("GET")) {
			 for(Data post : postsList) {
				 OtherRequest(method, url, post);
			 }			 
		 } else {
			 GetRequest(method, url, jsonOutput);
		 }
	}
	
	private static void GetRequest(String method, String url, String outputFilePath) {
		 JsonConnectHelper jsonConnectHelper = new JsonConnectHelper();
		 HttpClient client = HttpClients.createDefault();
		 HttpResponse response = jsonConnectHelper.httpResponse(client, method, url, null);
		 String result = null;
		 try {
			           
            HttpEntity entity = response.getEntity();

            if (entity != null) {
                // return it as a String
            	result = EntityUtils.toString(entity);
                System.out.println(result);
            }
            
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser jp = new JsonParser();
			JsonElement je = jp.parse(result);
            String prettyJsonString = gson.toJson(je);
            boolean fileWriteResult = JsonWriter(prettyJsonString, outputFilePath);
            if (fileWriteResult) {
            	System.out.println(fileWriteResult);
            }
           
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void OtherRequest(String method, String url, Data data) {
		 JsonConnectHelper jsonConnectHelper = new JsonConnectHelper();
		 HttpClient client = HttpClients.createDefault();
		 try {
			Gson gson = new Gson();
			StringEntity postingString = new StringEntity(gson.toJson(data));
			HttpResponse response = jsonConnectHelper.httpResponse(client, method, url, postingString);
			System.out.println(gson.toJson(data));
			System.out.println(response.getProtocolVersion());              // HTTP/1.1
            System.out.println(response.getStatusLine().getStatusCode());   // 200
            System.out.println(response.getStatusLine().getReasonPhrase()); // OK
            System.out.println(response.getStatusLine().toString());     
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static boolean JsonWriter(String prettyJsonString, String outputFilePath) {
		
		 boolean result = false;
		 try (FileWriter file = new FileWriter(outputFilePath)) {            	 
             file.write(prettyJsonString);
             file.flush();
             result = true;
         } catch (IOException e) {
             e.printStackTrace();                
         }
		
		 return result;
	}

}
