package json.test.bean;

import java.util.List;

public class Posts {
	private List<Data> result;

	public List<Data> getData() {
		return result;
	}

	public void setData(List<Data> result) {
		this.result = result;
	}
}
